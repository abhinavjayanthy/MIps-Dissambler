This program is written in python, to comply this please follow the instructions in this file and program as well

1) Run the program in the command prompt or terminal with the command as 

	python Mips_Diss.py

Mips_Diss.py is the file name

2) Give the input file name in the program 

3) The output should be as Mips.txt